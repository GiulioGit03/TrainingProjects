﻿namespace AirBnbCodeFirst.Models
{
	public class HouseToRent : BaseEntity
	{
		public string HouseName { get; set; }
		public string HouseType { get; set; }
		public string MaxGuests { get; set; }
		public string SuggestedSeason { get; set; }
		public int HostId { get; set; }
		public int CityId { get; set; }
		public string HouseAddress { get; set; }
		public decimal HousePrice { get; set; }


		public virtual City City { get; set; }
		public virtual Host Host { get; set; }
		public virtual IEnumerable<Booking> Bookings { get; set; } = new List<Booking>();





	}
}
