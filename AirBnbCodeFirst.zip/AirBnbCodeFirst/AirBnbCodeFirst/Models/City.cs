﻿namespace AirBnbCodeFirst.Models
{
	public class City : BaseEntity
	{
		public string CityName { get; set; }
		public int NationId { get; set; }

		public virtual Nation Nation { get; set; }
		public IEnumerable<HouseToRent> HouseToRents { get; set; } = new List<HouseToRent>();


	}
}
