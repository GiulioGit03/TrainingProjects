﻿namespace AirBnbCodeFirst.Models
{
	public class Nation : BaseEntity
	{
		public string NationName { get; set; }
		public string Description { get; set; }
		public string SuggestedSeason { get; set; }


		public virtual IEnumerable<City> Cities { get; set; } = new List<City>();
	}
}
