﻿namespace AirBnbCodeFirst.Models
{
	public class Client : BaseEntity
	{

		public string Name { get; set; }
		public string Surname	{ get; set; }
		public string Email { get; set; }
		public string Password { get; set; }
		
	public virtual IEnumerable<Booking> Bookings { get; set; } = new List<Booking>();



	}
}
