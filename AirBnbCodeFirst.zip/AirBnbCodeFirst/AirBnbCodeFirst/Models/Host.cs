﻿namespace AirBnbCodeFirst.Models
{
	public class Host : BaseEntity
	{
		public string Name { get; set; }
		public string Surname { get; set; }
		public string Email { get; set; }
		public string Password { get; set; }
		public bool IsVerified { get; set; }
		public decimal Rating { get; set; }

		public virtual IEnumerable<HouseToRent> HousesToRent { get; set; } = new List<HouseToRent>();


	}
}