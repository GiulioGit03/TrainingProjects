﻿namespace AirBnbCodeFirst.Models
{
	public class Booking : BaseEntity
	{
		public int ClientId { get; set; }
		public int HouseId { get; set; }
		public DateTime StartRent { get; set; }
		public DateTime EndRent { get; set; }
		public decimal TotalPrice { get; set; }

		public virtual HouseToRent HouseToRent { get; set; }
		
		public virtual IEnumerable<Client> Clients { get; set; } = new List<Client>();


	}
}
