﻿using AirBnbCodeFirst.Models;
using Microsoft.EntityFrameworkCore;

namespace AirBnbCodeFirst.Context
{
	public class AirBnBDbContext : DbContext
	{
		public AirBnBDbContext(DbContextOptions<AirBnBDbContext> options) : base(options) { }


		public DbSet<Booking> Bookings { get; set; }
		public DbSet<City> Cities { get; set; }
		public DbSet<Client> Clients { get; set; }
		public DbSet<Models.Host> Hosts { get; set; }
		public DbSet<HouseToRent> HouseToRents { get; set; }
		public DbSet<Nation> Nations { get; set; }


		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Booking>()
				.HasOne(h => h.HouseToRent)
				.WithMany(h => h.Bookings)
				.HasForeignKey(h => h.HouseId)
				.OnDelete(DeleteBehavior.Restrict);


			modelBuilder.Entity<Booking>()
				.HasMany(h => h.Clients)
				.WithMany(h => h.Bookings)
				.UsingEntity("ClientBooking");
				

			modelBuilder.Entity<City>()
				.HasOne(c=> c.Nation)
				.WithMany(n=> n.Cities)
				.HasForeignKey(n=> n.NationId)
				.OnDelete(DeleteBehavior.Cascade);

			modelBuilder.Entity<Client>()
				.HasMany(b => b.Bookings)
				.WithMany(b => b.Clients);

			modelBuilder.Entity<Models.Host>()
				.HasMany(h => h.HousesToRent)
				.WithOne(h => h.Host);

			modelBuilder.Entity<HouseToRent>()
				.HasOne(h => h.City)
				.WithMany(h => h.HouseToRents)
				.HasForeignKey(h => h.CityId)
				.OnDelete(DeleteBehavior.Cascade);
			
			modelBuilder.Entity<HouseToRent>()
				.HasOne(h=>h.Host)
				.WithMany(h=>h.HousesToRent)
				.HasForeignKey(h=>h.HostId)
				.OnDelete(DeleteBehavior.Cascade);

			modelBuilder.Entity<Nation>()
				.HasMany(h => h.Cities)
				.WithOne(h => h.Nation);

			modelBuilder.Entity<Client>()
				.Property(c => c.Email)
				.IsRequired();

			modelBuilder.Entity<Client>()
			.HasIndex(c => c.Email)
			.IsUnique();

			modelBuilder.Entity<HouseToRent>()
				.Property(h => h.HousePrice)
				.HasColumnType("decimal(8,2)");


		}
	}
}
