﻿using System.ComponentModel.DataAnnotations;

namespace ShoesShopCodeFirst.Models
{
	public class Brand : BaseEntity
	{
		[Required]
		public string Name { get; set; }

		public decimal Rating { get; set; }

		
		public virtual IEnumerable<ShoesCollab> ShoesCollabs { get; set; } = new List<ShoesCollab>();

	}
}
