﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ShoesShopCodeFirst.Models
{
	public class Order : BaseEntity
	{
		[Column(TypeName =("decimal(10,2)"))]
		public decimal TotalAmount { get; set; }
		public int ClientId { get; set; }

		public virtual Client Client { get; set; }

		public virtual IEnumerable<Shoe> Shoes { get; set; } = new List<Shoe>();
	}
}
