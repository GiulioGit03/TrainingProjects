﻿namespace ShoesShopCodeFirst.Models
{
	public class ShoesCollab : BaseEntity
	{
		public int ShoeId { get; set; }
		public int BrandId	{ get; set; }

		public virtual Shoe Shoe { get; set; }
		public virtual Brand Brand { get; set; }
	}
}
