﻿namespace ShoesShopCodeFirst.Models
{
	public class WareHouse : BaseEntity
	{
		public string Country { get; set; }
		public string Name	{ get; set; }
		public int MaxStock { get; set; }

		public virtual IEnumerable<Shoe> Shoes { get; set; } = new List<Shoe>(); 
	}
}
