﻿namespace ShoesShopCodeFirst.Models.Dtos
{
	public class WareHouseDto
	{
		public int Id { get; set; }
		public DateTime CreatedAt { get; set; } 
		public DateTime UpdatedAt { get; set; } 
		public string Country { get; set; }
		public string Name { get; set; }
		public int MaxStock { get; set; }
		public ICollection<ShoeDto> Shoes { get; set; } = new List<ShoeDto>();
	}
}
