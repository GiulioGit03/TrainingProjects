﻿namespace ShoesShopCodeFirst.Models.Dtos
{
	public class ShoeDto
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public decimal Cost { get; set; }
		public int Size { get; set; }
	}
}
