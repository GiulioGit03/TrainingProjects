﻿namespace ShoesShopCodeFirst.Models
{
	public class Client : BaseEntity
	{
		public string Username { get; set; }
		public string Password { get; set; }	
		public string Email { get; set; }
		public int FidelityPoint { get; set; }
		
		public virtual IEnumerable<Order> Orders { get; set; } = new List<Order>();
	}
}
