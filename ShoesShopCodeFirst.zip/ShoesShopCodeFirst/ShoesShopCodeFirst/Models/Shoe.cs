﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShoesShopCodeFirst.Models
{
	public class Shoe : BaseEntity
	{
		[Required]
		public String Name { get; set; }
		[Required]
		[Column(TypeName = ("decimal(10,2)"))]
		public decimal Cost { get; set; }
		[Required]
		public int Size { get; set; }

		
		public virtual ICollection<WareHouse> WareHouses { get; set; } = new List<WareHouse>();
		public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
		public virtual ICollection<ShoesCollab> ShoesCollabs { get; set; } = new List<ShoesCollab>();
	}
}
