﻿namespace ShoesShopCodeFirst.Requests
{
	public class CreateShoeRequest
	{	
		public string Name { get; set; }
		public decimal Cost { get; set; }
		public int Size { get; set; }


	}
}
