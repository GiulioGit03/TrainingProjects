﻿namespace ShoesShopCodeFirst.Requests
{
	public class CreateShoesCollabRequest
	{
	}
}
