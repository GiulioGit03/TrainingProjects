﻿namespace ShoesShopCodeFirst.Requests
{
	public class CreateWareHouseRequest
	{
		public string Country { get; set; }
		public string Name { get; set; }
		public int MaxStock { get; set; }
	}
}
