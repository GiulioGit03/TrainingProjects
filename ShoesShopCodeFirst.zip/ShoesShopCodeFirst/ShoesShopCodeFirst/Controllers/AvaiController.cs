﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoesShopCodeFirst.DataDefinition;
using ShoesShopCodeFirst.Models.Dtos;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ShoesShopCodeFirst.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class AvaiController : ControllerBase
	{
		private readonly ShoesShopDbContext _context;

		public AvaiController(ShoesShopDbContext context)
		{
			_context = context;
		}

		// GET: api/<AvaiController>
		[HttpGet("/shoe/{shoeId}")]
		public async Task<ActionResult<ICollection<WareHouseDto>>> GetWareHouseByShoeId(int shoeId)
		{
			var warehouseList = await _context.Shoes.AsNoTracking().Where(x => x.Id == shoeId)
				  .Select(x => x.WareHouses.Select(y => new WareHouseDto
				  {
					  Country = y.Country,
					  Id = y.Id,
					  CreatedAt = y.CreatedAt,
					  MaxStock = y.MaxStock,
					  Name = y.Name,
				  }
			)).SelectMany(shh => shh).ToListAsync();
			return Ok(warehouseList);
		}

		// GET api/<AvaiController>/5
		[HttpGet("{id}")]
		public string Get(int id)
		{
			return "value";
		}

		// POST api/<AvaiController>
		[HttpPost]
		public void Post([FromBody] string value)
		{
		}

		// PUT api/<AvaiController>/5
		[HttpPut("{id}")]
		public void Put(int id, [FromBody] string value)
		{
		}

		// DELETE api/<AvaiController>/5
		[HttpDelete("{id}")]
		public void Delete(int id)
		{
		}
	}
}
