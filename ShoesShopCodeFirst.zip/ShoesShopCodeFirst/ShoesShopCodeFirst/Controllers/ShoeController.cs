﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoesShopCodeFirst.DataDefinition;
using ShoesShopCodeFirst.Models;
using ShoesShopCodeFirst.Models.Dtos;
using ShoesShopCodeFirst.Requests;

namespace ShoesShopCodeFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShoeController : ControllerBase
    {
        private readonly ShoesShopDbContext _context;

        public ShoeController(ShoesShopDbContext context)
        {
            _context = context;
        }

        // GET: api/Shoe
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ShoeDto>>> GetShoes()
        {

            var shoes = await _context.Shoes.AsNoTracking().Select(a => new ShoeDto
            {
                Id = a.Id,
                Name = a.Name,
                Cost = a.Cost,
                Size = a.Size,
                WareHouses = a.WareHouses.Select(z => new WareHouseDto
                {
                    Country = z.Country,
                    Id = z.Id,
                    Name = z.Name,
                    MaxStock = z.MaxStock,
                    CreatedAt = z.CreatedAt,
                }).ToList()
            }).ToListAsync();
            return Ok(shoes);
        }

        // GET: api/Shoe/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ShoeDto>> GetShoeById(int id)
        {
			var shoe = await _context.Shoes.AsNoTracking().Select(a => new ShoeDto
			{
				Id = a.Id,
				Name = a.Name,
				Cost = a.Cost,
				Size = a.Size,
			}).SingleAsync(w=>w.Id==id);
			return Ok(shoe);
		}

        // PUT: api/Shoe/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateShoe(int id, CreateShoeRequest shoeRequest)
		{
			var t = await _context.Shoes.FindAsync(id) ?? throw new InvalidOperationException();
            t.Size = shoeRequest.Size;
            t.Cost = shoeRequest.Cost;  
            t.Name = shoeRequest.Name;
            _context.Entry(t).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return Ok();
		}

        // POST: api/Shoe
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ShoeDto>> CreateShoe(CreateShoeRequest shoeToAdd)
        {
            var shoe = _context.Shoes.Add(new Shoe
            {
                Cost = shoeToAdd.Cost,
                Name = shoeToAdd.Name,
                Size = shoeToAdd.Size
            }).Entity;
        await _context.SaveChangesAsync();
            return new ShoeDto
            {
                Id = shoe.Id,
                Name = shoe.Name,
                Size = shoe.Size,
                Cost = shoe.Cost,
            };
        }

        // DELETE: api/Shoe/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteShoeDto(int id)
        {
            try {
				var index = _context.Shoes.Single(a => a.Id == id);
                _context.Shoes.Remove(index);
                await _context.SaveChangesAsync();
                return Ok("Shoes deleted successfuly!");
            }
            catch
            {
                throw new ArgumentException(nameof(id), "Not associated shoes found");
            }


		}

        private bool ShoeDtoExists(int id)
        {
            return _context.ShoeDto.Any(e => e.Id == id);
        }
    }
}
