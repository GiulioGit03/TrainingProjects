﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoesShopCodeFirst.DataDefinition;
using ShoesShopCodeFirst.Models;
using ShoesShopCodeFirst.Models.Dtos;
using ShoesShopCodeFirst.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoesShopCodeFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WareHouseController : ControllerBase
    {
        private readonly ShoesShopDbContext _context;

        public WareHouseController(ShoesShopDbContext context)
        {
            _context = context;
        }

        // GET: api/WareHouse
        [HttpGet]
        public async Task<ActionResult<IEnumerable<WareHouseDto>>> GetWareHouses()
        {
            var warehouse = await _context.WareHouses.AsNoTracking().Select(a => new WareHouseDto
            {
                Id = a.Id,
                Name = a.Name,
                Country = a.Country,
                MaxStock = a.MaxStock,
                UpdatedAt = a.CreatedAt,
                CreatedAt = a.UpdatedAt,

            }).ToListAsync();
            return Ok(warehouse);
        }

        // GET: api/WareHouse/5
        [HttpGet("{id}")]
        public async Task<ActionResult<WareHouseDto>> GetWareHouseById(int id)
        {
            var wareHouseDto = await _context.WareHouses.AsNoTracking().Select(w => new WareHouseDto
            {
                Id = w.Id,
                Country = w.Country,
                CreatedAt = w.CreatedAt,
                UpdatedAt = w.UpdatedAt,
                MaxStock = w.MaxStock,
                Name = w.Name
            }).SingleAsync(w => w.Id == id);

            return Ok(wareHouseDto);
        }

        // PUT: api/WareHouse/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateWareHouse(int id, CreateWareHouseRequest wareHouseRequest)
        {
            var t = await _context.WareHouses.FindAsync(id) ?? throw new InvalidOperationException();

            t.MaxStock = wareHouseRequest.MaxStock;
            t.Name = wareHouseRequest.Name;
            t.Country = wareHouseRequest.Country;
            t.UpdatedAt = DateTime.UtcNow;

            _context.Entry(t).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return Ok();
        }

        // POST: api/WareHouse
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<WareHouseDto>> PostWareHouseDto(CreateWareHouseRequest wareHouseCreate)
        {
            var warehouse = _context.WareHouses.Add(new WareHouse
            {
                MaxStock = wareHouseCreate.MaxStock,
                Country = wareHouseCreate.Country,
                Name = wareHouseCreate.Name,
            }).Entity;
            await _context.SaveChangesAsync();

            return new WareHouseDto
            {
                Id = warehouse.Id,
                Name = warehouse.Name,
                CreatedAt = warehouse.CreatedAt,
                UpdatedAt = warehouse.UpdatedAt,
                Country = warehouse.Country,
                MaxStock = warehouse.MaxStock
            };
        }

        // DELETE: api/WareHouse/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteWareHouseDto(int id)
        {
            var wareHouseDto = await _context.WareHouseDto.FindAsync(id);
            if (wareHouseDto == null)
            {
                return NotFound();
            }

            _context.WareHouseDto.Remove(wareHouseDto);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool WareHouseDtoExists(int id)
        {
            return _context.WareHouseDto.Any(e => e.Id == id);
        }
        [HttpPost("{wareHouseId}/shoe/{shoeId}")]
        public async Task<IActionResult> AddWareHouseToShoe(int wareHouseId, int shoeId)
        {
            var wareHouse = await _context.WareHouses.SingleAsync(w => w.Id == wareHouseId);
            var shoe = await _context.Shoes.SingleAsync(w => w.Id == shoeId);


            shoe.WareHouses.Add(wareHouse);
            await _context.SaveChangesAsync();
            return Ok();
        }

   
    }
}