﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoesShopCodeFirst.DataDefinition;
using ShoesShopCodeFirst.Models;
using ShoesShopCodeFirst.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoesShopCodeFirst.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class AvailabilityController : ControllerBase
	{
		private readonly ShoesShopDbContext _context;

		public AvailabilityController(ShoesShopDbContext context)
		{
			_context = context;
		}

		

		// GET: api/Availability/5
		

	}
}
