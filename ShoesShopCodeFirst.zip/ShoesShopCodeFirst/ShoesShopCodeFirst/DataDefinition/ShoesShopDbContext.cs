﻿using Microsoft.EntityFrameworkCore;
using ShoesShopCodeFirst.Models;

namespace ShoesShopCodeFirst.DataDefinition
{
	public class ShoesShopDbContext : DbContext
	{
		public ShoesShopDbContext(DbContextOptions<ShoesShopDbContext> options) : base(options)
		{
		}
		public DbSet<Brand> Brands { get; set; }
		public DbSet<Client> Clients { get; set; }
		public DbSet<Order> Orders { get; set; }
		public DbSet<Shoe> Shoes { get; set; }
		public DbSet<ShoesCollab> ShoesCollabs { get; set; }
		public DbSet<WareHouse> WareHouses { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{

			modelBuilder.Entity<WareHouse>()
				.HasMany(w => w.Shoes)
				.WithMany(w => w.WareHouses)
				.UsingEntity("ShoesAvailability");

			modelBuilder.Entity<Order>()
				.HasMany(w => w.Shoes)
				.WithMany(w => w.Orders)
				.UsingEntity("ShoesOrder");

			modelBuilder.Entity<Client>()
				.HasMany(w => w.Orders)
				.WithOne(w => w.Client)
				.HasForeignKey(w => w.ClientId)
				.OnDelete(DeleteBehavior.Cascade);


			modelBuilder.Entity<ShoesCollab>()
				.HasOne(w=>w.Shoe)
				.WithMany(w=>w.ShoesCollabs)
				.HasForeignKey(w=>w.ShoeId)
				.OnDelete(DeleteBehavior.Cascade);

			modelBuilder.Entity<ShoesCollab>()
				.HasOne(w => w.Brand)
				.WithMany(w => w.ShoesCollabs)
				.HasForeignKey(w => w.BrandId)
				.OnDelete(DeleteBehavior.Cascade);

			//modelBuilder.Entity<ShoesCollab>()
			//	.HasIndex(w => new { w.ShoeId, w.BrandId })
			//	.IsUnique();

			base.OnModelCreating(modelBuilder);
		}
	}
}
