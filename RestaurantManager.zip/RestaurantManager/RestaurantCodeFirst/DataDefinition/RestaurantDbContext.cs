﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using RestaurantCodeFirst.Models.Entities;
using RestaurantCodeFirst.Models.Dtos;

namespace RestaurantCodeFirst.DataDefinition
{
	public class RestaurantDbContext : DbContext
	{
		public RestaurantDbContext(DbContextOptions<RestaurantDbContext> options) : base(options)
		{

		}

		public DbSet<Chef> Chefs { get; set; }
		public DbSet<Dish> Dishes { get; set; }
		public DbSet<Ingredient> Ingredients { get; set; }
		public DbSet<Restaurant> Restaurants { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Chef>()
				.HasOne(r => r.Restaurant)
				.WithOne(r => r.Chef)
				.HasForeignKey<Restaurant>(r => r.ChefId)
				.OnDelete(DeleteBehavior.SetNull);

			modelBuilder.Entity<Dish>()
				.HasMany(r => r.Ingredients)
				.WithMany(r => r.Dishes)
				.UsingEntity("IngredientDishes",
				r => r.HasOne(typeof(Ingredient)).WithMany().HasForeignKey("IngredientId").HasPrincipalKey(nameof(Ingredient.Id)).OnDelete(DeleteBehavior.Cascade),
				r => r.HasOne(typeof(Dish)).WithMany().HasForeignKey("DishId").HasPrincipalKey(nameof(Dish.Id)).OnDelete(DeleteBehavior.Cascade),
				
				j => j.HasKey("DishId", "IngredientId"));


			modelBuilder.Entity<Dish>()
				.HasOne(r => r.Restaurant)
				.WithMany(r => r.Dishes)
				.HasForeignKey(r => r.RestaurantId)
				.OnDelete(DeleteBehavior.Cascade);


			modelBuilder.Entity<Ingredient>()
				.HasIndex(r => r.Name)
				.IsUnique();

			modelBuilder.Entity<Chef>().HasData(
	  new Chef
	  {
		  Id = 1,
		  Name = "Gordon",
		  Surname = "Ramsay",
		  Specialty = "British Cuisine",
		  Experience = 30,
		  CreatedAt = DateTime.UtcNow,
		  UpdatedAt = DateTime.UtcNow
	  },
	  new Chef
	  {
		  Id = 2,
		  Name = "Massimo",
		  Surname = "Bottura",
		  Specialty = "Italian Cuisine",
		  Experience = 25,
		  CreatedAt = DateTime.UtcNow,
		  UpdatedAt = DateTime.UtcNow
	  },
	  new Chef
	  {
		  Id = 3,
		  Name = "Alain",
		  Surname = "Ducasse",
		  Specialty = "French Cuisine",
		  Experience = 35,
		  CreatedAt = DateTime.UtcNow,
		  UpdatedAt = DateTime.UtcNow
	  }
  );

			// Seed Restaurants
			modelBuilder.Entity<Restaurant>().HasData(
				new Restaurant
				{
					Id = 1,
					Name = "The Golden Fork",
					Address = "123 Main St, London",
					ChefId = 1,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Restaurant
				{
					Id = 2,
					Name = "Osteria Francescana",
					Address = "Via Stella 22, Modena",
					ChefId = 2,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Restaurant
				{
					Id = 3,
					Name = "Le Louis XV",
					Address = "Place du Casino, Monaco",
					ChefId = 3,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				}
			);

			// Seed Dishes
			modelBuilder.Entity<Dish>().HasData(
				new Dish
				{
					Id = 1,
					Name = "Beef Wellington",
					Price = 45.99m,
					RestaurantId = 1,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Dish
				{
					Id = 2,
					Name = "Fish and Chips",
					Price = 18.50m,
					RestaurantId = 1,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Dish
				{
					Id = 3,
					Name = "Risotto alla Milanese",
					Price = 32.00m,
					RestaurantId = 2,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Dish
				{
					Id = 4,
					Name = "Tagliatelle al Ragù",
					Price = 28.00m,
					RestaurantId = 2,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Dish
				{
					Id = 5,
					Name = "Bouillabaisse",
					Price = 52.00m,
					RestaurantId = 3,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Dish
				{
					Id = 6,
					Name = "Ratatouille",
					Price = 26.00m,
					RestaurantId = 3,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				}
			);

			// Seed Ingredients
			modelBuilder.Entity<Ingredient>().HasData(
				new Ingredient
				{
					Id = 1,
					Name = "Beef Tenderloin",
					Category = "Meat",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 2,
					Name = "Puff Pastry",
					Category = "Bakery",
					IsAllergen = true,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 3,
					Name = "Mushrooms",
					Category = "Vegetables",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 4,
					Name = "Cod Fish",
					Category = "Seafood",
					IsAllergen = true,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 5,
					Name = "Potatoes",
					Category = "Vegetables",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 6,
					Name = "Arborio Rice",
					Category = "Grains",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 7,
					Name = "Saffron",
					Category = "Spices",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 8,
					Name = "Parmesan",
					Category = "Dairy",
					IsAllergen = true,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 9,
					Name = "Tomatoes",
					Category = "Vegetables",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 10,
					Name = "Zucchini",
					Category = "Vegetables",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 11,
					Name = "Eggplant",
					Category = "Vegetables",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				},
				new Ingredient
				{
					Id = 12,
					Name = "Bell Peppers",
					Category = "Vegetables",
					IsAllergen = false,
					CreatedAt = DateTime.UtcNow,
					UpdatedAt = DateTime.UtcNow
				}
			);

			// Seed Many-to-Many: Dish-Ingredients (tabella join)
			modelBuilder.Entity("IngredientDishes").HasData(
				// Beef Wellington (Dish 1)
				new { DishId = 1, IngredientId = 1 },
				new { DishId = 1, IngredientId = 2 },
				new { DishId = 1, IngredientId = 3 },

				// Fish and Chips (Dish 2)
				new { DishId = 2, IngredientId = 4 },
				new { DishId = 2, IngredientId = 5 },

				// Risotto (Dish 3)
				new { DishId = 3, IngredientId = 6 },
				new { DishId = 3, IngredientId = 7 },
				new { DishId = 3, IngredientId = 8 },

				// Tagliatelle (Dish 4)
				new { DishId = 4, IngredientId = 1 },
				new { DishId = 4, IngredientId = 9 },

				// Bouillabaisse (Dish 5)
				new { DishId = 5, IngredientId = 4 },
				new { DishId = 5, IngredientId = 9 },

				// Ratatouille (Dish 6)
				new { DishId = 6, IngredientId = 9 },
				new { DishId = 6, IngredientId = 10 },
				new { DishId = 6, IngredientId = 11 },
				new { DishId = 6, IngredientId = 12 }
			);

		}
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.ConfigureWarnings(warnings =>
			warnings.Ignore(RelationalEventId.PendingModelChangesWarning));
		}
	    
	}
}
