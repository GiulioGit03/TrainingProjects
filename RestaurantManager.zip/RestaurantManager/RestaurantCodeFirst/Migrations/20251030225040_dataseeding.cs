﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RestaurantCodeFirst.Migrations
{
    /// <inheritdoc />
    public partial class dataseeding : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Chefs",
                columns: new[] { "Id", "CreatedAt", "Experience", "Name", "Specialty", "Surname", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, new DateTime(2025, 10, 30, 22, 50, 40, 137, DateTimeKind.Utc).AddTicks(6593), 30, "Gordon", "British Cuisine", "Ramsay", new DateTime(2025, 10, 30, 22, 50, 40, 137, DateTimeKind.Utc).AddTicks(6818) },
                    { 2, new DateTime(2025, 10, 30, 22, 50, 40, 137, DateTimeKind.Utc).AddTicks(7028), 25, "Massimo", "Italian Cuisine", "Bottura", new DateTime(2025, 10, 30, 22, 50, 40, 137, DateTimeKind.Utc).AddTicks(7029) },
                    { 3, new DateTime(2025, 10, 30, 22, 50, 40, 137, DateTimeKind.Utc).AddTicks(7030), 35, "Alain", "French Cuisine", "Ducasse", new DateTime(2025, 10, 30, 22, 50, 40, 137, DateTimeKind.Utc).AddTicks(7031) }
                });

            migrationBuilder.InsertData(
                table: "Ingredients",
                columns: new[] { "Id", "Category", "CreatedAt", "IsAllergen", "Name", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, "Meat", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6564), false, "Beef Tenderloin", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6564) },
                    { 2, "Bakery", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6569), true, "Puff Pastry", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6569) },
                    { 3, "Vegetables", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6571), false, "Mushrooms", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6572) },
                    { 4, "Seafood", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6573), true, "Cod Fish", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6574) },
                    { 5, "Vegetables", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6575), false, "Potatoes", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6576) },
                    { 6, "Grains", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6577), false, "Arborio Rice", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6578) },
                    { 7, "Spices", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6579), false, "Saffron", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6580) },
                    { 8, "Dairy", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6581), true, "Parmesan", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6582) },
                    { 9, "Vegetables", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6583), false, "Tomatoes", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6584) },
                    { 10, "Vegetables", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6586), false, "Zucchini", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6586) },
                    { 11, "Vegetables", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6588), false, "Eggplant", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6588) },
                    { 12, "Vegetables", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6590), false, "Bell Peppers", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(6590) }
                });

            migrationBuilder.InsertData(
                table: "Restaurants",
                columns: new[] { "Id", "Address", "ChefId", "CreatedAt", "Name", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, "123 Main St, London", 1, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(3565), "The Golden Fork", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(3566) },
                    { 2, "Via Stella 22, Modena", 2, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(3572), "Osteria Francescana", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(3573) },
                    { 3, "Place du Casino, Monaco", 3, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(3575), "Le Louis XV", new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(3575) }
                });

            migrationBuilder.InsertData(
                table: "Dishes",
                columns: new[] { "Id", "CreatedAt", "Name", "Price", "RestaurantId", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5247), "Beef Wellington", 45.99m, 1, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5247) },
                    { 2, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5285), "Fish and Chips", 18.50m, 1, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5286) },
                    { 3, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5288), "Risotto alla Milanese", 32.00m, 2, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5288) },
                    { 4, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5290), "Tagliatelle al Ragù", 28.00m, 2, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5290) },
                    { 5, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5292), "Bouillabaisse", 52.00m, 3, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5293) },
                    { 6, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5294), "Ratatouille", 26.00m, 3, new DateTime(2025, 10, 30, 22, 50, 40, 138, DateTimeKind.Utc).AddTicks(5295) }
                });

            migrationBuilder.InsertData(
                table: "IngredientDishes",
                columns: new[] { "DishId", "IngredientId" },
                values: new object[,]
                {
                    { 1, 1 },
                    { 1, 2 },
                    { 1, 3 },
                    { 2, 4 },
                    { 2, 5 },
                    { 3, 6 },
                    { 3, 7 },
                    { 3, 8 },
                    { 4, 1 },
                    { 4, 9 },
                    { 5, 4 },
                    { 5, 9 },
                    { 6, 9 },
                    { 6, 10 },
                    { 6, 11 },
                    { 6, 12 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 1, 1 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 1, 2 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 1, 3 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 2, 4 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 2, 5 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 3, 6 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 3, 7 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 3, 8 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 4, 1 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 4, 9 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 5, 4 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 5, 9 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 6, 9 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 6, 10 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 6, 11 });

            migrationBuilder.DeleteData(
                table: "IngredientDishes",
                keyColumns: new[] { "DishId", "IngredientId" },
                keyValues: new object[] { 6, 12 });

            migrationBuilder.DeleteData(
                table: "Dishes",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Dishes",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Dishes",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Dishes",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Dishes",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Dishes",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Ingredients",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Restaurants",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Restaurants",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Restaurants",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Chefs",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Chefs",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Chefs",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
