﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantCodeFirst.DataDefinition;
using RestaurantCodeFirst.Models.Dtos;
using RestaurantCodeFirst.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantCodeFirst.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class IngredientDishesController : ControllerBase
	{
		private readonly RestaurantDbContext _context;

		public IngredientDishesController(RestaurantDbContext context)
		{
			_context = context;
		}
		[HttpGet("/ingredient/{ingredientId}")]
		public async Task<ActionResult<ICollection<DishDto>>> GetDishByIngredientId(int ingredientId)
		{
			var dishList = await _context.Ingredients.AsNoTracking().Where(d => d.Id == ingredientId)
				 .Select(x => x.Dishes.Select(x => new DishDto
				 {
					 Id = x.Id,
					 Name = x.Name,
					 Price = x.Price,
					 RestaurantId = x.Id

				 })).SelectMany(s => s).ToListAsync();
			return Ok(dishList);

		}
		// GET: api/IngredientDishes
		[HttpGet("/dish/{dishId}")]
		public async Task<ActionResult<ICollection<IngredientDto>>> GetIngredientByDishId(int dishId)
		{
			var ingredientList = await _context.Dishes.AsNoTracking().Where(d => d.Id == dishId)
				 .Select(x => x.Ingredients.Select(x => new IngredientDto
				 {
					 Id = x.Id,
					 Name = x.Name,
					 Category = x.Category,
					 IsAllergen = x.IsAllergen

				 })).SelectMany(s => s).ToListAsync();
			return Ok(ingredientList);

		}

		// GET: api/IngredientDishes/5
		[HttpGet("GetAll")]
		public async Task<ActionResult<IEnumerable<IngredientDishesDto>>> GetAllIngredientDishes()
		{
			var ingredientDishes = await _context.Dishes.AsNoTracking()
				  .Select(i => i.Ingredients.Select(d => new IngredientDishesDto
				  {
					  DishId = d.Id,
					  DishName = d.Name,
					  IngredientId = i.Id,
					  IngredientName = i.Name,

				  })).SelectMany(s => s).ToListAsync();
			return Ok(ingredientDishes);
		}

		// PUT: api/IngredientDishes/5
		// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
		//[HttpPut("{id}")]
		//public async Task<IActionResult> PutIngredientDishesDto(int id, IngredientDishesDto ingredientDishesDto)
		//{
		//    if (id != ingredientDishesDto.DishId)
		//    {
		//        return BadRequest();
		//    }

		//    _context.Entry(ingredientDishesDto).State = EntityState.Modified;

		//    try
		//    {
		//        await _context.SaveChangesAsync();
		//    }
		//    catch (DbUpdateConcurrencyException)
		//    {
		//        if (!IngredientDishesDtoExists(id))
		//        {
		//            return NotFound();
		//        }
		//        else
		//        {
		//            throw;
		//        }
		//    }

		//    return NoContent();
		//}

		// POST: api/IngredientDishes
		// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
		[HttpPost("/dishid/{dishId}/ingredientId/{ingredientId}")]

		public async Task<ActionResult<IngredientDishesDto>> PostIngredientDishesDto(int dishId, int ingredientId)
		{
			var dish = await _context.Dishes.SingleAsync(d => d.Id == dishId);
			var ingredient = await _context.Ingredients.SingleAsync(d => d.Id == ingredientId);

			dish.Ingredients.Add(ingredient);
			await _context.SaveChangesAsync();
			return Ok();
		}


		[HttpDelete("/dishid/{dishId}/ingredientId/{ingredientId}")]
		public async Task<IActionResult> DeleteIngredientDishesDto(int dishId, int ingredientId)
		{
			var dish = await _context.Dishes
		.Include(d => d.Ingredients)  
		.SingleOrDefaultAsync(d => d.Id == dishId);

			if (dish == null)
				return NotFound($"Dish with ID {dishId} not found");

			var ingredient = dish.Ingredients.FirstOrDefault(i => i.Id == ingredientId);

			if (ingredient == null)
				return NotFound($"Ingredient with ID {ingredientId} not found in this dish");

			dish.Ingredients.Remove(ingredient);  

			await _context.SaveChangesAsync();

			return Ok();
		}


	}
}
