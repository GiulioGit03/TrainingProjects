﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantCodeFirst.DataDefinition;
using RestaurantCodeFirst.Models.Dtos;
using RestaurantCodeFirst.Models.Entities;
using RestaurantCodeFirst.Models.Requests;

namespace RestaurantCodeFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChefController : ControllerBase
    {
        private readonly RestaurantDbContext _context;

        public ChefController(RestaurantDbContext context)
        {
            _context = context;
        }

        // GET: api/Chef
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ChefDto>>> GetChefs()
        {
            var chefs = await _context.Chefs.AsNoTracking().Select(c=>new ChefDto
            {
                Id = c.Id,
                Name = c.Name,
                Surname = c.Surname,
                Specialty = c.Specialty,
                CreatedAt = c.CreatedAt,
                UpdatedAt = c.UpdatedAt,
                Experience = c.Experience,
                
            }).ToListAsync();
            return chefs;
        }

        // GET: api/Chef/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ChefDto>> GetChefById(int id)
        {
			var chef = await _context.Chefs.AsNoTracking().Select(c => new ChefDto
			{
				Id = c.Id,
				Name = c.Name,
				Surname = c.Surname,
				Specialty = c.Specialty,
				CreatedAt = c.CreatedAt,
				UpdatedAt = c.UpdatedAt,
				Experience = c.Experience,

			}).SingleAsync(w=>w.Id==id);
            return chef;
		}

        // PUT: api/Chef/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateChef(int id,UpsertChefRequest newChef)
        {
            var c = await _context.Chefs.FindAsync(id);
            if (c == null) return NotFound();
            c.Surname = newChef.Surname;
            c.Name = newChef.Name;
            c.UpdatedAt = DateTime.UtcNow;
            c.Experience = newChef.Experience;
            c.Specialty = newChef.Specialty;
            _context.Entry(c).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return Ok();
        }

        // POST: api/Chef
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ChefDto>> CreateChef(UpsertChefRequest c)
        {
            var chef = _context.Chefs.Add(new Chef
            {
                Name = c.Name,
                Surname = c.Surname,
                Experience = c.Experience,
                Specialty = c.Specialty

            });
            await _context.SaveChangesAsync();
            return Ok();
        }

        // DELETE: api/Chef/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteChefDto(int id)
        {
            var chefToDelete =await  _context.Chefs.SingleAsync(c => c.Id == id);
            _context.Chefs.Remove(chefToDelete);
            await _context.SaveChangesAsync();
            return Ok("Chef with name: "+chefToDelete.Surname+" deleted");
        }

       
    }
}
