﻿using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantCodeFirst.Models.Dtos
{
	public class DishDto : BaseEntityDto
	{
		public string Name { get; set; }


		public decimal Price { get; set; }
		public int RestaurantId { get; set; }
	}
}
