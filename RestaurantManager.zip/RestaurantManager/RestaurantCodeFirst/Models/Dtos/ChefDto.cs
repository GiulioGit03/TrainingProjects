﻿namespace RestaurantCodeFirst.Models.Dtos
{
	public class ChefDto : BaseEntityDto
	{
		public string Name { get; set; }
		public string Surname { get; set; }
		public int Experience { get; set; }
		public string Specialty { get; set; }
	}
}
