﻿namespace RestaurantCodeFirst.Models.Dtos
{
	public class BaseEntityDto
	{
		public int Id { get; set; }
		public DateTime CreatedAt { get; set; } 
		public DateTime UpdatedAt { get; set; }
	}
}
