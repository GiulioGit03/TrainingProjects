﻿namespace RestaurantCodeFirst.Models.Dtos
{
	public class RestaurantDto
	{
	}
}
