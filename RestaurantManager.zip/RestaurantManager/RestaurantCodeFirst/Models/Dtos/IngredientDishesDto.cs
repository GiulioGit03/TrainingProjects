﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantCodeFirst.Models.Dtos
{
	public class IngredientDishesDto
	{
	
		public int DishId { get; set; }
		
		public int IngredientId { get; set; }
		public string IngredientName { get; set; }
		public string DishName { get; set; }
	}
}
