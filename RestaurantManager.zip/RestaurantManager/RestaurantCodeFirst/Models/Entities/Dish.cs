﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantCodeFirst.Models.Entities
{
	public class Dish : BaseEntity 
	{
		[Required]
		public string  Name { get; set; }

		[Column(TypeName ="Decimal(8,2)")]
        public decimal Price { get; set; }            
        public int RestaurantId { get; set; }

		public virtual ICollection<Ingredient> Ingredients { get; set; }	= new List<Ingredient>();
		public Restaurant Restaurant { get; set; }
	}
}
