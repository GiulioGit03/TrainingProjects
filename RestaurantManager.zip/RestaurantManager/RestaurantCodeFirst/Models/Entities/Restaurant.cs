﻿namespace RestaurantCodeFirst.Models.Entities
{
	public class Restaurant : BaseEntity
	{
		public string Name { get; set; }
		public string Address { get; set; }
		public int? ChefId { get; set; }
		public Chef Chef { get; set; }

		public ICollection<Dish> Dishes { get; set; } = new List<Dish>();
	}
}
