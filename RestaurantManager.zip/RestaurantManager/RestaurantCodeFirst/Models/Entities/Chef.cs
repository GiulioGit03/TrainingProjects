﻿namespace RestaurantCodeFirst.Models.Entities
{
	public class Chef : BaseEntity
	{
		public string Name { get; set; }
		public string Surname { get; set; }
		public int Experience { get; set; }
		public string Specialty	{ get; set; }
		
		public Restaurant Restaurant { get; set; }

	}
}
