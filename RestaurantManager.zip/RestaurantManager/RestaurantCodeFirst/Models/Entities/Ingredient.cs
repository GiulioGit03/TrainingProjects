﻿namespace RestaurantCodeFirst.Models.Entities
{
	public class Ingredient : BaseEntity
	{
		public string Name { get; set; }
		public bool IsAllergen { get; set; }
		public string Category { get; set; }

		public virtual ICollection<Dish> Dishes { get; set; }= new List<Dish>();
	}
}
