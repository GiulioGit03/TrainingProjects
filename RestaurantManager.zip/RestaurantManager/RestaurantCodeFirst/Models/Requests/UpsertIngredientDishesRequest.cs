﻿namespace RestaurantCodeFirst.Models.Requests
{
	public class UpsertIngredientDishesRequest
	{
		public int DishId { get; set; }
		public int IngredientId { get; set; }
		
	}
}
