﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MagazinesCodeFirst;
using MagazinesCodeFirst.Model;
using MagazinesCodeFirst.Dto;
using MagazinesCodeFirst.Request;

namespace MagazinesCodeFirst.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class MagazineManagerController : ControllerBase
	{
		private readonly MagazineDbContext _context;

		public MagazineManagerController(MagazineDbContext context)
		{
			_context = context;
		}

		// GET: api/MagazineManager
		[HttpGet("{id}")]
		public async Task<ActionResult<MagazineDto>> GetMagazineById(int id)
		{
			//var magazine = await _context.Magazines.AsNoTracking().Include(x => x.Writers).SingleOrDefaultAsync(m => m.Id == id);
			//if(magazine == null) return NotFound();
			//return Ok(magazine);

			//var magazine = await _context.Magazines.AsNoTracking().Include(x => x.Writers).Select(m => new MagazineDto
			//{
			//	Name = m.Name,
			//	PagesNumber = m.PagesNumber,
			//	CategoryId = m.CategoryId,
			//	Description = m.Description,
			//	Category = m.Category,
			//	Writers = m.Writers.Select(a => new Writer
			//	{
			//		Id = a.Id,
			//		Name = a.Name,
			//		CreatedAt = a.CreatedAt,
			//		Magazines = a.Magazines.Select(a => new Magazine
			//		{
			//			Name = a.Name,
			//			Category = a.Category,
			//			Description = a.Description,


			//		}).ToList()
			//	}).ToList()
			//}).ToListAsync();
			//return Ok(magazine);

			var magazine = await _context.Magazines.AsNoTracking().Where(a => a.Id == id)
				.Select(a => new MagazineDto
				{
					Writers = a.Writers.Select(a => new WriterDto
					{
						Name = a.Name
					}).ToList()
				}).SingleAsync();


			return Ok(magazine);

		}


		[HttpGet("{id}/writer")]
		public async Task<ActionResult<IEnumerable<WriterDto>>> GetWriterByMagazineId(int id)
		{
			var exist = await _context.Magazines.AsNoTracking().Include(a => a.Writers).SingleOrDefaultAsync(a => a.Id == id);
			if (exist == null) return NotFound();
			var writers = exist.Writers.Select(a => new WriterDto
			{
				Name = a.Name
			});
			return Ok(writers);
		}
		// PUT: api/MagazineManager/5
		// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
		[HttpPut("{id}")]
		public async Task<IActionResult> PutMagazine(int id, Magazine magazine)
		{
			var findMagazine = await _context.Magazines.SingleOrDefaultAsync(a => a.Id == id);
			if (findMagazine == null) return NotFound();
			findMagazine.Name = magazine.Name;
			findMagazine.UpdatedAt = DateTime.UtcNow;
			findMagazine.Description = magazine.Description;
			findMagazine.Category = magazine.Category;
			await _context.SaveChangesAsync();
			return Ok(findMagazine);
		}

		// POST: api/MagazineManager
		// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
		[HttpPost]
		[Route("PostMagazine")]
		public async Task<ActionResult<Magazine>> PostMagazine(UpsertMagazineRequest magazine)
		{
			// 1. Validazione: verifica che i Writers esistano
			if (magazine.WriterIds != null && magazine.WriterIds.Any())
			{
				var existingWriterIds = await _context.Writers
					.Where(w => magazine.WriterIds.Contains(w.Id))
					.Select(w => w.Id)
					.ToListAsync();

				if (existingWriterIds.Count != magazine.WriterIds.Count)
				{
					return BadRequest("One or more WriterIds are invalid");
				}
			}

			// 2. Crea il Magazine
			var magazineNew = new Magazine
			{
				CreatedAt = DateTime.UtcNow,
				CategoryId = magazine.CategoryId,
				Name = magazine.Name,
				Description = magazine.Description,
				PagesNumber = magazine.PagesNumber
			};

			// 3. Carica i Writers dal database e associali
			if (magazine.WriterIds != null && magazine.WriterIds.Any())
			{
				var writers = await _context.Writers
					.Where(w => magazine.WriterIds.Contains(w.Id))
					.ToListAsync();

				magazineNew.Writers = writers;
			}

			// 4. Aggiungi e salva
			_context.Magazines.Add(magazineNew);
			await _context.SaveChangesAsync();

			// 5. Ricarica il magazine con le relazioni per ritornarlo completo
			var createdMagazine = await _context.Magazines
				
				.FirstOrDefaultAsync(m => m.Id == magazineNew.Id);

			return CreatedAtAction(nameof(GetMagazineById), new { id = magazineNew.Id }, createdMagazine);
		}

		// DELETE: api/MagazineManager/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteMagazine(int id)
		{
			var magazine = await _context.Magazines.SingleOrDefaultAsync(a => a.Id == id);
			if (magazine == null) { return NotFound(); }
			_context.Magazines.Remove(magazine);
			return Ok();
		}

		//[HttpGet("search")]
		//public async Task<ActionResult<IEnumerable<Product>>> SearchProducts(
		//[FromQuery] string? searchTerm,
		//[FromQuery] decimal? minPrice)
		//{ 
		//}
		//}
	}
}
