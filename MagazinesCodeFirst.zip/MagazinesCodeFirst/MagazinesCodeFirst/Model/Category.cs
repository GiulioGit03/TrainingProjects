﻿using System.Text.Json.Serialization;

namespace MagazinesCodeFirst.Model
{
	public class Category : BaseEntity
	{
		public string Name { get; set; }

	
		public virtual ICollection<Magazine> Magazines { get; set; } = new List<Magazine>();
	}
}
