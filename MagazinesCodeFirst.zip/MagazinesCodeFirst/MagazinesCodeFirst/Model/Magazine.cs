﻿using System.Text.Json.Serialization;

namespace MagazinesCodeFirst.Model
{
	public class Magazine : BaseEntity
	{
		public string Name { get; set; }
		public string Description { get; set; }
		public int PagesNumber { get; set; }
		public int? CategoryId { get; set; }
		[JsonIgnore]
		public virtual Category Category { get; set; }
		public virtual ICollection<Writer> Writers { get; set; } = new List<Writer>();
	}
}
