﻿using MagazinesCodeFirst.Model;

namespace MagazinesCodeFirst.Request
{
	public class UpsertMagazineRequest
	{
		public string Name { get; set; }
		public string Description { get; set; }
		public int PagesNumber { get; set; }
		public int? CategoryId { get; set; }

		public List<int>? WriterIds { get; set; }

	}
}
