﻿using MagazinesCodeFirst.Model;

namespace MagazinesCodeFirst.Dto
{
	public class MagazineDto
	{
		public string Name { get; set; }
		public string Description { get; set; }
		public int PagesNumber { get; set; }
		public int? CategoryId { get; set; }

		public virtual Category Category { get; set; }
		public virtual ICollection<WriterDto> Writers { get; set; } = new List<WriterDto>();
	}
}
