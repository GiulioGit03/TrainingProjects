﻿using MagazinesCodeFirst.Model;
using System.Text.Json.Serialization;

namespace MagazinesCodeFirst.Dto
{
	public class WriterDto
	{
		public string Name { get; set; }

		[JsonIgnore]
		// Navigation property for N:N relationship
		public virtual ICollection<Magazine> Magazines { get; set; } = new List<Magazine>();
	}
}
