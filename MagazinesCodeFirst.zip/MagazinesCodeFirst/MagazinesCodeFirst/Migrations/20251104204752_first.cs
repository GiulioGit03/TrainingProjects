﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace MagazinesCodeFirst.Migrations
{
    /// <inheritdoc />
    public partial class first : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Writers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Writers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Magazines",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PagesNumber = table.Column<int>(type: "int", nullable: false),
                    CategoryId = table.Column<int>(type: "int", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Magazines", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Magazines_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "MagazineWriters",
                columns: table => new
                {
                    WritersId = table.Column<int>(type: "int", nullable: false),
                    MagazinesId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MagazineWriters", x => new { x.WritersId, x.MagazinesId });
                    table.ForeignKey(
                        name: "FK_MagazineWriters_Magazines_MagazinesId",
                        column: x => x.MagazinesId,
                        principalTable: "Magazines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MagazineWriters_Writers_WritersId",
                        column: x => x.WritersId,
                        principalTable: "Writers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "CreatedAt", "Name", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(4437), "Technology", new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(4440) },
                    { 2, new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5023), "Fashion", new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5024) },
                    { 3, new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5026), "Science", new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5026) },
                    { 4, new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5027), "Sports", new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5027) },
                    { 5, new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5028), "Travel", new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5028) },
                    { 6, new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5029), "Business", new DateTime(2025, 11, 4, 20, 47, 51, 621, DateTimeKind.Utc).AddTicks(5029) }
                });

            migrationBuilder.InsertData(
                table: "Magazines",
                columns: new[] { "Id", "CategoryId", "CreatedAt", "Description", "Name", "PagesNumber", "UpdatedAt" },
                values: new object[] { 13, null, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2708), "An uncategorized magazine covering diverse topics and perspectives", "The Independent Reader", 105, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2709) });

            migrationBuilder.InsertData(
                table: "Writers",
                columns: new[] { "Id", "CreatedAt", "Name", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(452), "John Smith", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(453) },
                    { 2, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(756), "Emma Johnson", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(757) },
                    { 3, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(758), "Michael Brown", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(758) },
                    { 4, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(759), "Sarah Davis", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(759) },
                    { 5, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(760), "David Wilson", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(760) },
                    { 6, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(761), "Lisa Anderson", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(761) },
                    { 7, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(762), "James Martinez", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(762) },
                    { 8, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(763), "Maria Garcia", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(764) },
                    { 9, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(765), "Robert Taylor", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(765) },
                    { 10, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(805), "Jennifer Lee", new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(805) }
                });

            migrationBuilder.InsertData(
                table: "MagazineWriters",
                columns: new[] { "MagazinesId", "WritersId" },
                values: new object[,]
                {
                    { 13, 1 },
                    { 13, 2 },
                    { 13, 4 },
                    { 13, 10 }
                });

            migrationBuilder.InsertData(
                table: "Magazines",
                columns: new[] { "Id", "CategoryId", "CreatedAt", "Description", "Name", "PagesNumber", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(1708), "Leading magazine covering the latest in technology, gadgets, and innovation", "TechWorld Monthly", 120, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(1708) },
                    { 2, 1, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2690), "Exploring artificial intelligence, robotics, and the future of technology", "Digital Future", 95, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2691) },
                    { 3, 2, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2694), "Your ultimate guide to fashion, beauty, and lifestyle trends", "Style & Trends", 150, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2694) },
                    { 4, 2, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2695), "Italian fashion at its finest, showcasing haute couture and street style", "Vogue Italia", 180, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2696) },
                    { 5, 3, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2697), "Discover breakthroughs in physics, chemistry, biology, and space exploration", "Science Today", 110, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2697) },
                    { 6, 3, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2698), "Understanding our planet through environmental science and ecology", "Nature Explorer", 88, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2699) },
                    { 7, 4, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2700), "Comprehensive coverage of football, basketball, and international sports", "Sports Illustrated", 100, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2700) },
                    { 8, 4, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2701), "Your guide to staying fit, healthy eating, and athletic performance", "Fitness & Health", 75, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2701) },
                    { 9, 5, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2703), "Inspiring travel destinations, cultural experiences, and adventure stories", "Wanderlust", 140, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2703) },
                    { 10, 5, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2704), "Luxury travel, hidden gems, and unforgettable vacation ideas", "Travel + Leisure", 130, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2704) },
                    { 11, 6, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2706), "Market analysis, entrepreneurship, and corporate strategy insights", "Business Weekly", 85, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2706) },
                    { 12, 6, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2707), "Stories of startup success, innovation, and business leadership", "Entrepreneur Now", 92, new DateTime(2025, 11, 4, 20, 47, 51, 622, DateTimeKind.Utc).AddTicks(2707) }
                });

            migrationBuilder.InsertData(
                table: "MagazineWriters",
                columns: new[] { "MagazinesId", "WritersId" },
                values: new object[,]
                {
                    { 1, 1 },
                    { 2, 1 },
                    { 3, 2 },
                    { 4, 2 },
                    { 1, 3 },
                    { 5, 3 },
                    { 3, 4 },
                    { 9, 4 },
                    { 1, 5 },
                    { 7, 5 },
                    { 4, 6 },
                    { 9, 6 },
                    { 10, 6 },
                    { 2, 7 },
                    { 11, 7 },
                    { 12, 7 },
                    { 4, 8 },
                    { 9, 8 },
                    { 10, 8 },
                    { 5, 9 },
                    { 6, 9 },
                    { 11, 9 },
                    { 7, 10 },
                    { 8, 10 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Magazines_CategoryId",
                table: "Magazines",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_MagazineWriters_MagazinesId",
                table: "MagazineWriters",
                column: "MagazinesId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MagazineWriters");

            migrationBuilder.DropTable(
                name: "Magazines");

            migrationBuilder.DropTable(
                name: "Writers");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
