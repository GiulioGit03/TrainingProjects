﻿using MagazinesCodeFirst.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace MagazinesCodeFirst
{
	public class MagazineDbContext : DbContext
	{
		public MagazineDbContext(DbContextOptions options) : base(options)
		{
		}

		public DbSet<Magazine> Magazines { get; set; }
		public DbSet<Category> Categories { get; set; }
		public DbSet<Writer> Writers { get; set; }


		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Magazine>()
				.HasMany(a => a.Writers)
				.WithMany(a => a.Magazines)
				.UsingEntity("MagazineWriters",
				r => r.HasOne(typeof(Writer)).WithMany().HasForeignKey("WritersId").HasPrincipalKey(nameof(Writer.Id)).OnDelete(DeleteBehavior.Cascade),
				l => l.HasOne(typeof(Magazine)).WithMany().HasForeignKey("MagazinesId").HasPrincipalKey(nameof(Magazine.Id)).OnDelete(DeleteBehavior.Cascade),
				j => j.HasKey("WritersId", "MagazinesId"));

			modelBuilder.Entity<Magazine>()
				.HasOne(a => a.Category)
				.WithMany(a => a.Magazines)
				.HasForeignKey(a => a.CategoryId)
				.OnDelete(DeleteBehavior.SetNull);


			modelBuilder.Entity<Category>().HasData(
			   new Category { Id = 1, Name = "Technology" },
			   new Category { Id = 2, Name = "Fashion" },
			   new Category { Id = 3, Name = "Science" },
			   new Category { Id = 4, Name = "Sports" },
			   new Category { Id = 5, Name = "Travel" },
			   new Category { Id = 6, Name = "Business" }
		   );

			// ============================================
			// SEED WRITERS
			// ============================================
			modelBuilder.Entity<Writer>().HasData(
				new Writer { Id = 1, Name = "John Smith" },
				new Writer { Id = 2, Name = "Emma Johnson" },
				new Writer { Id = 3, Name = "Michael Brown" },
				new Writer { Id = 4, Name = "Sarah Davis" },
				new Writer { Id = 5, Name = "David Wilson" },
				new Writer { Id = 6, Name = "Lisa Anderson" },
				new Writer { Id = 7, Name = "James Martinez" },
				new Writer { Id = 8, Name = "Maria Garcia" },
				new Writer { Id = 9, Name = "Robert Taylor" },
				new Writer { Id = 10, Name = "Jennifer Lee" }
			);

			// ============================================
			// SEED MAGAZINES
			// ============================================
			modelBuilder.Entity<Magazine>().HasData(
				// Technology
				new Magazine
				{
					Id = 1,
					Name = "TechWorld Monthly",
					Description = "Leading magazine covering the latest in technology, gadgets, and innovation",
					PagesNumber = 120,
					CategoryId = 1
				},
				new Magazine
				{
					Id = 2,
					Name = "Digital Future",
					Description = "Exploring artificial intelligence, robotics, and the future of technology",
					PagesNumber = 95,
					CategoryId = 1
				},

				// Fashion
				new Magazine
				{
					Id = 3,
					Name = "Style & Trends",
					Description = "Your ultimate guide to fashion, beauty, and lifestyle trends",
					PagesNumber = 150,
					CategoryId = 2
				},
				new Magazine
				{
					Id = 4,
					Name = "Vogue Italia",
					Description = "Italian fashion at its finest, showcasing haute couture and street style",
					PagesNumber = 180,
					CategoryId = 2
				},

				// Science
				new Magazine
				{
					Id = 5,
					Name = "Science Today",
					Description = "Discover breakthroughs in physics, chemistry, biology, and space exploration",
					PagesNumber = 110,
					CategoryId = 3
				},
				new Magazine
				{
					Id = 6,
					Name = "Nature Explorer",
					Description = "Understanding our planet through environmental science and ecology",
					PagesNumber = 88,
					CategoryId = 3
				},

				// Sports
				new Magazine
				{
					Id = 7,
					Name = "Sports Illustrated",
					Description = "Comprehensive coverage of football, basketball, and international sports",
					PagesNumber = 100,
					CategoryId = 4
				},
				new Magazine
				{
					Id = 8,
					Name = "Fitness & Health",
					Description = "Your guide to staying fit, healthy eating, and athletic performance",
					PagesNumber = 75,
					CategoryId = 4
				},

				// Travel
				new Magazine
				{
					Id = 9,
					Name = "Wanderlust",
					Description = "Inspiring travel destinations, cultural experiences, and adventure stories",
					PagesNumber = 140,
					CategoryId = 5
				},
				new Magazine
				{
					Id = 10,
					Name = "Travel + Leisure",
					Description = "Luxury travel, hidden gems, and unforgettable vacation ideas",
					PagesNumber = 130,
					CategoryId = 5
				},

				// Business
				new Magazine
				{
					Id = 11,
					Name = "Business Weekly",
					Description = "Market analysis, entrepreneurship, and corporate strategy insights",
					PagesNumber = 85,
					CategoryId = 6
				},
				new Magazine
				{
					Id = 12,
					Name = "Entrepreneur Now",
					Description = "Stories of startup success, innovation, and business leadership",
					PagesNumber = 92,
					CategoryId = 6
				},

				// No category
				new Magazine
				{
					Id = 13,
					Name = "The Independent Reader",
					Description = "An uncategorized magazine covering diverse topics and perspectives",
					PagesNumber = 105,
					CategoryId = null
				}
			);
			modelBuilder.Entity("MagazineWriters") 
			  .HasData(
				   // TechWorld Monthly (1) - 3 autori
				   new { MagazinesId = 1, WritersId = 1 },
				   new { MagazinesId = 1, WritersId = 3 },
				   new { MagazinesId = 1, WritersId = 5 },

				   // Digital Future (2) - 2 autori
				   new { MagazinesId = 2, WritersId = 1 },
				   new { MagazinesId = 2, WritersId = 7 },

				   // Style & Trends (3) - 2 autori
				   new { MagazinesId = 3, WritersId = 2 },
				   new { MagazinesId = 3, WritersId = 4 },

				   // Vogue Italia (4) - 3 autori
				   new { MagazinesId = 4, WritersId = 2 },
				   new { MagazinesId = 4, WritersId = 6 },
				   new { MagazinesId = 4, WritersId = 8 },

				   // Science Today (5) - 2 autori
				   new { MagazinesId = 5, WritersId = 3 },
				   new { MagazinesId = 5, WritersId = 9 },

				   // Nature Explorer (6) - 1 autore
				   new { MagazinesId = 6, WritersId = 9 },

				   // Sports Illustrated (7) - 2 autori
				   new { MagazinesId = 7, WritersId = 5 },
				   new { MagazinesId = 7, WritersId = 10 },

				   // Fitness & Health (8) - 1 autore
				   new { MagazinesId = 8, WritersId = 10 },

				   // Wanderlust (9) - 3 autori
				   new { MagazinesId = 9, WritersId = 4 },
				   new { MagazinesId = 9, WritersId = 6 },
				   new { MagazinesId = 9, WritersId = 8 },

				   // Travel + Leisure (10) - 2 autori
				   new { MagazinesId = 10, WritersId = 6 },
				   new { MagazinesId = 10, WritersId = 8 },

				   // Business Weekly (11) - 2 autori
				   new { MagazinesId = 11, WritersId = 7 },
				   new { MagazinesId = 11, WritersId = 9 },

				   // Entrepreneur Now (12) - 1 autore
				   new { MagazinesId = 12, WritersId = 7 },

				   // Independent Reader (13) - 4 autori
				   new { MagazinesId = 13, WritersId = 1 },
				   new { MagazinesId = 13, WritersId = 2 },
				   new { MagazinesId = 13, WritersId = 4 },
				   new { MagazinesId = 13, WritersId = 10 }
			   );
		}
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.ConfigureWarnings(warnings =>
			warnings.Ignore(RelationalEventId.PendingModelChangesWarning));
		}
	}
}
