﻿namespace CollegeManager.Model
{
    public class Teacher : BaseEntity
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Degree { get; set; }

        public virtual ICollection<Course> Courses { get; set; } = new List<Course>();
    }
}
