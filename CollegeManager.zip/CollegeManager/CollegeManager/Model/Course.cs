﻿namespace CollegeManager.Model
{
    public class Course : BaseEntity
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public int Cfu { get; set; }
        public int LessonDuration { get; set; }
        public int Year { get; set; }
        public bool IsActive { get; set; }
        public int DepartmentId { get; set; }

        public virtual ICollection<Teacher> Teachers {  get; set; } = new List<Teacher>();
        public virtual Department Department { get; set; }
    }
}
