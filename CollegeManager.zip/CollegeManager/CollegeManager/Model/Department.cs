﻿namespace CollegeManager.Model
{
    public class Department : BaseEntity
    {
        public string Name { get; set; }
        public int Floor { get; set; }
        public string Location { get; set; }


        public virtual ICollection<Course> Courses { get; set; } = new List<Course>();

    }
}
