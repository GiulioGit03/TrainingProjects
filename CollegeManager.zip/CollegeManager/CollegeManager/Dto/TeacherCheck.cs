﻿namespace CollegeManager.Dto
{
    public class TeacherCheck
    {
        public int Id {  get; set; }
    }
}
