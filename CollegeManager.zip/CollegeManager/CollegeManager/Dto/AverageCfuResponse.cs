﻿namespace CollegeManager.Dto
{
    public class AverageCfuResponse
    {
        
  
        public double CfuAverage { get; set; }
        public string TeacherName { get; set; }

    }
}
