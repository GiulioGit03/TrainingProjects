﻿namespace CollegeManager.Dto
{
    public class CourseInsertRequest
    {

        public string Name { get; set; }
        public string Code { get; set; }
        public int Cfu { get; set; }
        public int LessonDuration { get; set; }
        public int Year { get; set; }
        public bool IsActive { get; set; }
        public int DepartmentId { get; set; }

    }
}
