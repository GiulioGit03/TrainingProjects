﻿namespace CollegeManager.Dto
{
    public class TeacherStatsResponse
    {
        public string FullName { get; set; }
        public int TotalCourses { get; set; }
        public int TotalCfuCourses { get; set; }
        public double AverageLessonHours { get; set; }

    }
}
