﻿namespace CollegeManager.Dto
{
    public class CourseCheck
    {
        public int Id { get; set; }
    }
}
