﻿using CollegeManager.Model;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CollegeManager.Dto
{
    public class HighLoadTeachersResponse
    {

        //        5. Docenti con Carico Elevato
        //Endpoint: GET /api/docenti/carico-alto? minimoCorsi = 3

        //Ritorna i docenti che insegnano almeno minimoCorsi corsi, con il dettaglio di:

        //Nome completo
        //Numero di corsi
        //Lista dei nomi dei corsi
        //Ordinare per numero di corsi(decrescente).



        public string FullNameTeacher {  get; set; }
        public int CourseNumber { get; set; }
        public List<string> NameCourseList { get; set; } = new List<string>();

    }
}
