﻿namespace CollegeManager.Dto
{
    public class TeacherResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Degree { get; set; }
    }
}
