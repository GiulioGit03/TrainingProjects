﻿namespace CollegeManager.Dto
{
    public class TeacherCoursesDto
    {
        public int CourseId { get; set; }
        public int TeacherId { get; set; }
        public string CourseName { get; set; }
        public string TeacherName { get; set; }


    }
}
