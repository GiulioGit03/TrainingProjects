﻿using CollegeManager.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using CollegeManager.Dto;

namespace CollegeManager.Context
{
    public class CollegeDbContext : DbContext
    {
        public CollegeDbContext(DbContextOptions<CollegeDbContext> options) : base(options)
        {
        }

        public DbSet<Course> Courses { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Teacher> Teachers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Course>()
                .HasMany(a => a.Teachers)
                .WithMany(a => a.Courses)
                .UsingEntity("TeacherCourses",

                r => r.HasOne(typeof(Teacher)).WithMany().HasForeignKey("TeacherId").HasPrincipalKey(nameof(Teacher.Id)).OnDelete(DeleteBehavior.Cascade),
                l => l.HasOne(typeof(Course)).WithMany().HasForeignKey("CourseId").HasPrincipalKey(nameof(Course.Id)).OnDelete(DeleteBehavior.Cascade),
                j => j.HasKey("TeacherId", "CourseId")
                );

            modelBuilder.Entity<Course>()
                .HasOne(a => a.Department)
                .WithMany(a => a.Courses)
                .HasForeignKey(a => a.DepartmentId);

            modelBuilder.Entity<Department>()
                .HasData(
                new Department { Id = 1, Floor = 1, Location = "Italy", Name = "Medicine" },
                new Department { Id = 2, Floor = 2, Location = "France", Name = "Engineering" },
                new Department { Id = 3, Floor = 3, Location = "Germany", Name = "Science" },
                new Department { Id = 4, Floor = 4, Location = "Swiss", Name = "Biology" }
                );

            modelBuilder.Entity<Course>()
                .HasData(
                new Course { Id = 1, Name = "Technology", DepartmentId = 1, Code = "SA1241", Cfu = 12, IsActive = true, Year = 2025, LessonDuration = 2 },
                new Course { Id = 2, Name = "Science", DepartmentId = 2, Code = "SA1433", Cfu = 8, IsActive = true, Year = 2025, LessonDuration = 2 },
                new Course { Id = 3, Name = "Economy", DepartmentId = 3, Code = "SA1432", Cfu = 7, IsActive = true, Year = 2025, LessonDuration = 2 },
                new Course { Id = 4, Name = "Finance", DepartmentId = 4, Code = "SA1434", Cfu = 8, IsActive = true, Year = 2025, LessonDuration = 2 }

                );
            modelBuilder.Entity<Teacher>()
              .HasData(
                new Teacher { Id = 1, Surname = "Rossi", Degree = "Science", Name = "Maria", Email = "maria@gmail.com" },
                new Teacher { Id = 2, Surname = "Verdi", Degree = "Engineering", Name = "Marcello", Email = "marcello@gmail.com" },
                new Teacher { Id = 3, Surname = "Bianchi", Degree = "Math", Name = "Francesca", Email = "francesca@gmail.com" },
                new Teacher { Id = 4, Surname = "Neri", Degree = "DAMS", Name = "Marta", Email = "marta@gmail.com" }
                );
            modelBuilder.Entity("TeacherCourses")
             .HasData(
        new { TeacherId = 1, CourseId = 1 },
        new { TeacherId = 2, CourseId = 3 },
        new { TeacherId = 2, CourseId = 2 },
        new { TeacherId = 3, CourseId = 2 },
        new { TeacherId = 4, CourseId = 3 },
        new { TeacherId = 4, CourseId = 4 }
       );
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.ConfigureWarnings(warnings =>
            warnings.Ignore(RelationalEventId.PendingModelChangesWarning));
        }
        
    }
}
