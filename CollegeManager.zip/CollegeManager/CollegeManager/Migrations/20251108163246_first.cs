﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace CollegeManager.Migrations
{
    /// <inheritdoc />
    public partial class first : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Floor = table.Column<int>(type: "int", nullable: false),
                    Location = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Teachers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Degree = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Teachers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Courses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Cfu = table.Column<int>(type: "int", nullable: false),
                    LessonDuration = table.Column<int>(type: "int", nullable: false),
                    Year = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    DepartmentId = table.Column<int>(type: "int", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Courses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Courses_Departments_DepartmentId",
                        column: x => x.DepartmentId,
                        principalTable: "Departments",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TeacherCourses",
                columns: table => new
                {
                    TeacherId = table.Column<int>(type: "int", nullable: false),
                    CourseId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TeacherCourses", x => new { x.TeacherId, x.CourseId });
                    table.ForeignKey(
                        name: "FK_TeacherCourses_Courses_CourseId",
                        column: x => x.CourseId,
                        principalTable: "Courses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TeacherCourses_Teachers_TeacherId",
                        column: x => x.TeacherId,
                        principalTable: "Teachers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "Id", "CreatedAt", "Floor", "Location", "Name", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, new DateTime(2025, 11, 8, 16, 32, 46, 230, DateTimeKind.Utc).AddTicks(9278), 1, "Italy", "Medicine", new DateTime(2025, 11, 8, 16, 32, 46, 230, DateTimeKind.Utc).AddTicks(9280) },
                    { 2, new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(219), 2, "France", "Engineering", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(219) },
                    { 3, new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(221), 3, "Germany", "Science", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(221) },
                    { 4, new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(222), 4, "Swiss", "Biology", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(223) }
                });

            migrationBuilder.InsertData(
                table: "Teachers",
                columns: new[] { "Id", "CreatedAt", "Degree", "Email", "Name", "Surname", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(7897), "Science", "maria@gmail.com", "Maria", "Rossi", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(7898) },
                    { 2, new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(8772), "Engineering", "marcello@gmail.com", "Marcello", "Verdi", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(8773) },
                    { 3, new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(8774), "Math", "francesca@gmail.com", "Francesca", "Bianchi", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(8775) },
                    { 4, new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(8776), "DAMS", "marta@gmail.com", "Marta", "Neri", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(8776) }
                });

            migrationBuilder.InsertData(
                table: "Courses",
                columns: new[] { "Id", "Cfu", "Code", "CreatedAt", "DepartmentId", "IsActive", "LessonDuration", "Name", "UpdatedAt", "Year" },
                values: new object[,]
                {
                    { 1, 12, "SA1241", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(5586), 1, true, 2, "Technology", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(5587), 2025 },
                    { 2, 8, "SA1433", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(7120), 2, true, 2, "Science", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(7121), 2025 },
                    { 3, 7, "SA1432", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(7123), 3, true, 2, "Economy", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(7124), 2025 },
                    { 4, 8, "SA1434", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(7125), 4, true, 2, "Finance", new DateTime(2025, 11, 8, 16, 32, 46, 231, DateTimeKind.Utc).AddTicks(7126), 2025 }
                });

            migrationBuilder.InsertData(
                table: "TeacherCourses",
                columns: new[] { "CourseId", "TeacherId" },
                values: new object[,]
                {
                    { 1, 1 },
                    { 2, 2 },
                    { 3, 2 },
                    { 2, 3 },
                    { 3, 4 },
                    { 4, 4 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Courses_DepartmentId",
                table: "Courses",
                column: "DepartmentId");

            migrationBuilder.CreateIndex(
                name: "IX_TeacherCourses_CourseId",
                table: "TeacherCourses",
                column: "CourseId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TeacherCourses");

            migrationBuilder.DropTable(
                name: "Courses");

            migrationBuilder.DropTable(
                name: "Teachers");

            migrationBuilder.DropTable(
                name: "Departments");
        }
    }
}
