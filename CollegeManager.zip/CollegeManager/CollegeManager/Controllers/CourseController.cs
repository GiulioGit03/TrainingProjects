﻿using CollegeManager.Context;
using CollegeManager.Dto;
using CollegeManager.Model;
using Humanizer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CollegeManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly CollegeDbContext _context;
        public CourseController(CollegeDbContext context)
        {
            _context = context;
        }
        // GET: api/Course
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CourseResponse>>> GetAllCourses()
        {
            var courses = await _context.Courses.AsNoTracking().Select(c => new CourseResponse
            {
                Name = c.Name,
                Cfu = c.Cfu,
                Code = c.Code,
                DepartmentId = c.DepartmentId,
                Id = c.Id,
                IsActive = c.IsActive,
                LessonDuration = c.LessonDuration,
                Year = c.Year,
                DepartmentName = c.Department.Name,
            }).ToListAsync();
            return Ok(courses);
        }
        // GET: api/Course/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CourseResponse>> GetCourseById(int id)
        {
            var course = await _context.Courses.AsNoTracking().Select(c => new CourseResponse
            {
                Name = c.Name,
                Cfu = c.Cfu,
                Code = c.Code,
                DepartmentId = c.DepartmentId,
                Id = c.Id,
                IsActive = c.IsActive,
                LessonDuration = c.LessonDuration,
                Year = c.Year,
                DepartmentName = c.Department.Name,
            }).SingleOrDefaultAsync(a => a.Id == id);
            return Ok(course);
        }
        // PUT: api/Course/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCourseResponse(int id, [FromBody] CourseInsertRequest courseResponse)
        {
            var coursetoupdate = await _context.Courses.SingleOrDefaultAsync(a => a.Id == id);

            if (coursetoupdate != null)
            {
                coursetoupdate.Year = courseResponse.Year;
                coursetoupdate.Name = courseResponse.Name;
                coursetoupdate.UpdatedAt = DateTime.UtcNow;
                coursetoupdate.Cfu = courseResponse.Cfu;
                coursetoupdate.Code = courseResponse.Code;
                coursetoupdate.DepartmentId = courseResponse.DepartmentId;
                await _context.SaveChangesAsync();

                return Ok(coursetoupdate);
            }
            return NotFound();

        }
        // POST: api/Course
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<IActionResult> InsertCourse([FromBody] CourseInsertRequest courseRequest)
        {
            var coursetoadd = new Course
            {

                Name = courseRequest.Name,
                Cfu = courseRequest.Cfu,
                Code = courseRequest.Code,
                LessonDuration = courseRequest.LessonDuration,
                DepartmentId = courseRequest.DepartmentId,
                Year = courseRequest.Year,
                IsActive = courseRequest.IsActive,



            };
            await _context.Courses.AddAsync(coursetoadd);
            await _context.SaveChangesAsync();
            var department = await _context.Departments.SingleOrDefaultAsync(a => a.Id == courseRequest.DepartmentId);

            var response = new CourseResponse
            {
                Cfu = coursetoadd.Cfu,
                Id = coursetoadd.Id,
                Code = coursetoadd.Code,
                DepartmentId = coursetoadd.DepartmentId,
                LessonDuration = coursetoadd.LessonDuration,
                IsActive = coursetoadd.IsActive,
                DepartmentName = department.Name,
                Name = coursetoadd.Name,
                Year = coursetoadd.Year
            };



            return CreatedAtAction(
              nameof(GetCourseById),
              new { id = coursetoadd.Id },
              response);

        }
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteCourse(int id)
        {
            var coursetodelete = await _context.Courses.SingleOrDefaultAsync(a => a.Id == id);
            if (coursetodelete != null)
            {
                _context.Remove(coursetodelete);
                await _context.SaveChangesAsync();
                return Ok(true);
            }
            return NotFound();
        }
        //        1. Ricerca Avanzata Corsi
        //Endpoint: GET /api/corsi/advanced-search

        //Parametri opzionali:

        //nome(string) : ricerca parziale nel nome
        //codice(string) : ricerca parziale nel codice
        //cfuMin(int?) : CFU minimo
        //cfuMax(int?) : CFU massimo
        //anno(int?) : anno di corso
        //attivo(bool?): stato attivo/non attivo
        //dipartimentoId(int?) : filtra per dipartimento
        //docenteId(int?): corsi insegnati da questo docente
        //Esempio: /api/corsi/advanced-search? nome = programmazione & cfuMin = 6 & attivo = true & docenteId = 5

        //Ritorna i corsi che soddisfano TUTTI i criteri specificati.
        [HttpGet]
        [Route("AdvancedSearch")]
        public async Task<ActionResult<IEnumerable<CourseResponse>>> AdvancedCourseSearch([FromQuery(Name = "name")] string? name, [FromQuery(Name = "code")] string? code, [FromQuery(Name = "year")] int? year, [FromQuery(Name = "cfumin")] int? cfumin, [FromQuery(Name = "cfumax")] int? cfumax, [FromQuery(Name = "isActive")] bool? isActive, [FromQuery(Name = "departmentId")] int? departmentId, [FromQuery(Name = "teacherId")] int? teacherId)
        {
            var findedCourses = _context.Courses.AsNoTracking();
            if (name != null)
            {
                findedCourses = findedCourses.Where(f => f.Name.Contains(name));
            }
            if (code != null)
            {

                findedCourses = findedCourses.Where(f => f.Code.Contains(code));
            }
            if (cfumin != null)
            {
                findedCourses = findedCourses.Where(f => f.Cfu > cfumin);

            }
            if (cfumax != null)
            {
                findedCourses = findedCourses.Where(f => f.Cfu < cfumax);
            }
            if (isActive != null)
            {
                findedCourses = findedCourses.Where(f => f.IsActive == isActive);

            }
            if (departmentId != null)
            {
                findedCourses = findedCourses.Where(f => f.DepartmentId == departmentId);
            }


            var response = await findedCourses.Select(a => new CourseResponse
            {
                Name = a.Name,
                Id = a.Id,
                Cfu = a.Cfu,
                Code = a.Code,
                DepartmentId = a.DepartmentId,
                IsActive = a.IsActive,
                DepartmentName = a.Department.Name,
                LessonDuration = a.LessonDuration,
                Year = a.Year
            }
            ).ToListAsync();
            return Ok(response);
        }
        [HttpGet]
        [Route("{id}/Teacher/GetCoursesByTeacher")]
        public async Task<ActionResult<IEnumerable<CourseResponse>>> GetCoursesByTeacher(int id)
        {
            var teacher = await _context.Teachers.Include(a => a.Courses).ThenInclude(a => a.Department).SingleOrDefaultAsync(a => a.Id == id);


            var courses = teacher.Courses.Select(n => new CourseResponse
            {

                Name = n.Name,
                Id = n.Id,
                Cfu = n.Cfu,
                Code = n.Code,
                DepartmentId = n.DepartmentId,
                IsActive = n.IsActive,
                DepartmentName = n.Department.Name,
                LessonDuration = n.LessonDuration,
                Year = n.Year

            }).ToList();






            return Ok(courses);
        }
        [HttpGet]
        [Route("{id}/Course/GetTeacherByCourse")]
        public async Task<ActionResult<IEnumerable<TeacherResponse>>> GetTeacherByCourse(int id)
        {
            var course = await _context.Courses.AsNoTracking().Include(a => a.Teachers).SingleOrDefaultAsync(a => a.Id == id);


            var teachers = course.Teachers.Select(a => new TeacherResponse
            {
                Name = a.Name,
                Id = a.Id,

                Degree = a.Degree,
                Email = a.Email,
                Surname = a.Surname,

            }).ToList();

            return Ok(teachers);
        }
        [HttpPut]
        [Route("InsertTeacherCourses/{courseId}/{teacherId}")] 
        public async Task<ActionResult<TeacherCoursesDto>> InsertTeacherCourses(int courseId, int teacherId)
        {
            var course = await _context.Courses.Include(a => a.Teachers).SingleOrDefaultAsync(a => a.Id == courseId);
            var teacher = await _context.Teachers.Include(a => a.Courses).SingleOrDefaultAsync(a => a.Id == teacherId);



            if (course != null && teacher != null)
            {

                var teacherincurse = course.Teachers.Select(a => new TeacherCheck
                {
                    Id = a.Id
                }).ToList();
                var courseinteacher = teacher.Courses.Select(a => new CourseCheck
                {
                    Id = a.Id
                }).ToList();

                foreach (var item in teacherincurse)
                {
                    if (item.Id == teacherId)
                    {
                        return BadRequest("Teacher with id: " + teacherId + " already present in course with id: " + courseId);
                    }
                }
                foreach (var item in courseinteacher)
                {
                    if (item.Id == courseId)
                    {
                        return BadRequest("Course with id: " + courseId + " already present in teacher with id : " + teacherId);
                    }
                }

                course.Teachers.Add(teacher);
                teacher.Courses.Add(course);
                await _context.SaveChangesAsync();

                var tc = new TeacherCoursesDto
                {
                    CourseId = course.Id,
                    CourseName = course.Name,
                    TeacherId = teacher.Id,
                    TeacherName = teacher.Name,
                };

                return Ok(tc);
            }
            else
            {
                return NotFound();
            }

        }
        [HttpGet]
        [Route("/teachers/GetAverageCfuByTeacherCourses")]
        public async Task<ActionResult<IEnumerable<AverageCfuResponse>>> GetAverageCfuByTeacherCourses()
        {

            var average = await _context.Teachers.AsNoTracking().Include(a => a.Courses)
                .Where(a => a.Courses.Count > 0)
                .Select(a => new AverageCfuResponse
                {
                    CfuAverage = a.Courses.Average(a => a.Cfu),
                    TeacherName = a.Name
                }).ToListAsync();


            return Ok(average);




        }
        [HttpGet]
        [Route("/teachers/TeachersStats")]
        public async Task<ActionResult<IEnumerable<TeacherStatsResponse>>> GetTeachersStats()
        {
            var teacherStats = await _context.Teachers.Include(a => a.Courses)
                .AsNoTracking()
                .Where(a => a.Courses.Count() > 0)
                .Select(a => new TeacherStatsResponse
                {
                    FullName = ($"{a.Name} {a.Surname}"),
                    AverageLessonHours = a.Courses.Average(a => a.LessonDuration),
                    TotalCfuCourses = a.Courses.Sum(a => a.Cfu),
                    TotalCourses = a.Courses.Count()
                }
            ).ToListAsync();

            return Ok(teacherStats);

        }
        [HttpGet]
        [Route("/teachers/HighLoadTeachers")]
        public async Task<ActionResult<IEnumerable<TeacherStatsResponse>>> GetHighLoadTeachers(int minCourseTeached)
        {
            var teachers = await _context.Teachers.AsNoTracking()
                .Include(a => a.Courses)
                .Where(a => a.Courses.Count() >= minCourseTeached)
                .Select(a => new HighLoadTeachersResponse
                {
                    CourseNumber = a.Courses.Count(),
                    FullNameTeacher = ($"{a.Name} {a.Surname}"),
                    NameCourseList =a.Courses.Select(a=>a.Name).ToList()
                    
                    
                }).OrderByDescending(a=>a.CourseNumber).ToListAsync();

            return Ok(teachers);

        }

    }
}